This folder contained examples for libpmemobj C++ bindings.
They have been moved to https://github.com/pmem/libpmemobj-cpp/tree/master/examples
